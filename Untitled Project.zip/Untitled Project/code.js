onEvent("button1", "click", function( ) {
	var box1 = getText("text_input1");
	var box2 = getText("text_input2");
	var box3 = getText("text_input3");
	if (box1=="6" && box2=="2" && box3=="4") {
	  setScreen("winner");
	  playSound("assets/category_bell/bells_win_high.mp3", false);
	} else {
	  setScreen("tryagain");
	  playSound("assets/category_alerts/playful_game_error_sound_4.mp3", false);
	}
});
